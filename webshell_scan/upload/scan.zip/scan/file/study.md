> 2019-4-16

os.walk 便利目录文件的方法
multiprocessing 多线程
endswith 用于判断字符是否以指定字符串结尾
os.path.join 把文件名和路径结合成一串字符